﻿using System;
using System.Collections.Generic;

namespace angularTest.Models
{
    public partial class Faq
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
    }
}
