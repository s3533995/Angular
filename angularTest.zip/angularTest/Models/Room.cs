﻿using System;
using System.Collections.Generic;

namespace angularTest.Models
{
    public partial class Room
    {
        public int Id { get; set; }
        public string RoomId { get; set; }
    }
}
