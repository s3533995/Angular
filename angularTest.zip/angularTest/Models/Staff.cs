﻿using System;
using System.Collections.Generic;

namespace angularTest.Models
{
    public partial class Staff
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public string PassWord { get; set; }
    }
}
