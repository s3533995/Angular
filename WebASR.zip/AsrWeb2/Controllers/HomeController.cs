﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AsrWeb2.Models;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using AsrWeb2.Data;
using Microsoft.EntityFrameworkCore;

namespace AsrWeb2.Controllers
{ 
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public string SetInfo()
        {
            ViewData["User"] = "";
            string cook = "";
            if (Request.Cookies["userToken"] != null && Request.Cookies["userToken"] != "")
            {
                cook = Request.Cookies["userToken"];
                ViewData["User"] = "LoginOut";
                ViewBag.username = cook.Split("-")[0];
                ViewBag.email = cook.Split("-")[1];
            }
            return cook;
        }


        public IActionResult Index()
        {
            if (Request.Cookies["userToken"] == null)
            {
                Response.Cookies.Append("userToken", "");
            } 
            SetInfo();
            return View();
        }

        public IActionResult About()
        {
            SetInfo();
            ViewData["Message"] = "Your application description page.";

            return View();
        } 

        public IActionResult LoginOut()
        {
            Response.Cookies.Append("userToken", "");
            Response.Cookies.Append("staffToken", "");
            return Redirect("/Home");
        }

        public IActionResult Login()
        { 
            return Redirect("/Users/Login");
        }

        public IActionResult RegisterUser()
        {
            return View();
        }


        public IActionResult Contact()
        {
            SetInfo();
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        // POST: Users/Register
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RegisterUser([Bind("Id,UserID,Name,Email,PassWord")] User user)
        {
            var Tempuser = await _context.User
             .FirstOrDefaultAsync(m => m.UserID == user.UserID);
            if (Tempuser != null)
            {
                ViewData["Message"] = "Staff Exists";
                return View();
            }
            if (ModelState.IsValid)
            {
                _context.Add(user);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(user);
        }



        [HttpGet]
        public JsonResult SumaryStaffSlot()
        {
            string staffId = Request.Query["StaffID"]; 
            Slot[] menus = _context.Slot
                .Select(m => m).Where(m => m.StaffID == staffId).Where(m => m.BookedInStudentID != null).ToArray();
            return Json(menus);
        }


        [HttpGet]
        public JsonResult SumaryStudentSlot()
        {
            string studentID = Request.Query["StudentID"]; 
            Slot[] menus = _context.Slot
                .Select(m => m).Where(m => m.BookedInStudentID == studentID).Where(m => m.BookedInStudentID != null).ToArray();
            return Json(menus);
        }


 
        [HttpGet]
        public JsonResult CancelingSlot()
        {
            string studentID = Request.Query["StudentID"];
            string roomID = Request.Query["RoomID"];
            string staffId = Request.Query["StaffID"];
            string startTime = Request.Query["StartTime"]; 
            Slot[] menus = _context.Slot
                .Select(m => m).Where(m => m.BookedInStudentID == studentID).Where(m => m.RoomID == roomID).Where(m => m.StaffID == staffId).Where(m => m.StartTime.Contains(startTime)).ToArray();
            if(menus.Length == 1)
            {
                menus[0].BookedInStudentID = "";
                _context.Update(menus[0]);
            }
            return Json(menus);
        }

        [HttpGet]
        [ValidateAntiForgeryToken]
        public JsonResult EditSlot(int id, [Bind("Id,RoomID,BookedInStudentID,StaffID,StartTime")] Slot slot)
        {
            if (id != slot.Id)
            {
                return Json("not found");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(slot);
                    _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SlotExists(slot.Id))
                    {
                        return Json("not found");
                    }
                    else
                    {
                        throw;
                    }
                }
            }
            return Json("success ");
        }


        // GET: Home/Delete
        public JsonResult Delete(int? id)
        {
            if (id == null)
            {
                return Json("not found");
            }

            var user = _context.User
                .FirstOrDefaultAsync(m => m.Id == id);
            if (user == null)
            {
                return Json("not found");
            }

            return Json("success ");
        }

        private bool SlotExists(int id)
        {
            return _context.Slot.Any(e => e.Id == id);
        }

        // GET: Home/CreateRoom
        [HttpGet]
        [ValidateAntiForgeryToken]
        public JsonResult CreateRoom([Bind("Id,RoomID")] Room room)
        {
            if (ModelState.IsValid)
            {
                _context.Add(room);
                _context.SaveChangesAsync();
            }
            return Json("success ");
        }


        // GET: Home/EditRoom
        [HttpGet]
        [ValidateAntiForgeryToken]
        public JsonResult EditRoom(int id, [Bind("Id,RoomID")] Room room)
        {
            if (id != room.Id)
            {
                return Json("not found");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(room);
                    _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RoomExists(room.Id))
                    {
                        return Json("not found");
                    }
                    else
                    {
                        throw;
                    }
                }
            }
            return Json("success ");
        }

        private bool RoomExists(int id)
        {
            return _context.Room.Any(e => e.Id == id);
        }
    }
}
