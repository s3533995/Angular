﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AsrWeb2.Data;
using AsrWeb2.Models;

namespace AsrWeb2.Controllers
{
    public class UsersController : Controller
    {
        private readonly ApplicationDbContext _context;

        public UsersController(ApplicationDbContext context)
        { 
            _context = context;
        }


        public string SetInfo()
        { 
            string cook = "";
            if (Request.Cookies["userToken"] != null && Request.Cookies["userToken"] != "")
            {
                cook = Request.Cookies["userToken"];
                ViewData["User"] = "LoginOut";
                ViewBag.username = cook.Split("-")[0];
                ViewBag.email = cook.Split("-")[1];
            }
            return cook; 
        }

        // GET: Users
        public async Task<IActionResult> Index()
        { 
            if(SetInfo() == "")
            {
                return Redirect("/Users/Login");
            }
            return View(await _context.User.ToListAsync());
        }

        // GET: Users/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if(SetInfo() == "")
            {
                return Redirect("/Users/Login");
            }
            if (id == null)
            {
                return NotFound();
            }

            var user = await _context.User
                .FirstOrDefaultAsync(m => m.Id == id);
            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        // GET: Users/Login
        public IActionResult Login()
        {
            string cook = "";
            if (Request.Cookies["userToken"] != null && Request.Cookies["userToken"] != "")
            {
                cook = Request.Cookies["userToken"];
                ViewData["User"] = "LoginOut";
                if(cook[0] == 's')
                {
                    return Redirect("/Users/StudentMenu");
                }
                else if(cook[0] == 'e')
                {
                    return Redirect("/Users/StaffMenu");
                }
            }

            return View();
        }

        // GET: Users/StaffMenu
        public async Task<IActionResult> StaffMenu()
        {
            if(SetInfo() == "")
            {
                return Redirect("/Users/Login");
            }

            return View(await _context.User.ToListAsync());
        }

        // GET: Users/StudentMenu
        public async Task<IActionResult> StudentMenu()
        {
            if(SetInfo() == "")
            {
                return Redirect("/Users/Login");
            }
            return View(await _context.User.ToListAsync());
        }

        // GET: Users/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Users/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,UserID,Name,Email,PassWord")] User user)
        {
            if (ModelState.IsValid)
            {
                _context.Add(user);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(user);
        }

        // GET: Users/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = await _context.User.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }
            return View(user);
        }

        // POST: Users/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,UserID,Name,Email,PassWord")] User user)
        {
            if (id != user.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(user);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UserExists(user.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(user);
        }

        // GET: Users/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = await _context.User
                .FirstOrDefaultAsync(m => m.Id == id);
            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        // POST: Users/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var user = await _context.User.FindAsync(id);
            _context.User.Remove(user);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }


        // POST: Users/Login
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login([Bind("Id,UserID,PassWord")] User user)
        {
            var Tempuser = await _context.User
                .FirstOrDefaultAsync(m => m.UserID == user.UserID);
            if(Tempuser != null && Tempuser.PassWord == user.PassWord)
            {
                Response.Cookies.Append("userToken", user.UserID + "-" + Tempuser.Email);
                if (user.UserID[0] == 's')
                {
                    return Redirect("/Users/StudentMenu");
                }
                else if (user.UserID[0] == 'e')
                {
                    return Redirect("/Users/StaffMenu");
                }
            }
            ViewData["Message"] = "Login Failed";
            return View(); 
        }


        private bool UserExists(int id)
        {
            return _context.User.Any(e => e.Id == id);
        }
         
        [HttpPost, ActionName("RoomAvaliable")]
        [ValidateAntiForgeryToken]
        public IActionResult RoomAvaliable(int id)
        {
            if(SetInfo() == "")
            {
                return Redirect("/Users/Login");
            }
            ViewData["Message"] = CheckInvalidDate(Request.Form["Time"]);
            if (CheckInvalidDate(Request.Form["Time"]) != "")
            {
                return View();
            }
            string time = GetDateFormat(Request.Form["Time"]);
            List<Slot> menus = _context.Slot
                .Select(m => m).Where(m => m.StartTime.StartsWith(time)).Where(m => m.BookedInStudentID == null).ToList();
            List<Room> rooms = _context.Room.ToList();
            foreach (Slot item in menus)
            {
                foreach (Room sitem in rooms)
                {
                    if(item.RoomID == sitem.RoomID)
                    {
                        rooms.Remove(sitem);
                        break;
                    }

                }
            } 
            return View(rooms);
        }


        public string GetDateFormat(string date)
        {
            return date; 
        }

        public string CheckInvalidDate(string sDate)
        {
            if (sDate.Length != 10)
            {
                return "the date your input is invaild! please input again!";
            }
            if(Convert.ToDateTime(sDate) < Convert.ToDateTime(DateTime.Now.ToShortDateString()))
            {
                return "the date your input is invaild! please input again!";
            }
            return ""; 
        }

        public string CheckInvalidRoomId(string RoomID)
        {
            if (RoomID.Length != 1)
            {
                return "the RoomID length is 1! please input again!"; 
            }
            var room = _context.Room.Select(t => t).Where(t => t.RoomID == RoomID).ToList();
            if (room == null || room.Count == 0)
            {
                return "the database not has the RoomID! please input again!"; 
            }
            return "";
        }

        public string CheckInvalidTime(string sTime)
        {
            if (sTime.Length != 5 || sTime[2] != ':')
            {
               return "the date your input is invaild! please input again(hh:mm)!"; 
            }
            if(sTime[3] != '0' || sTime[4] != '0')
            {
                return "the date your input is invaild! please input again(hh:mm)!";
            }
            int hour = Convert.ToInt32(sTime.Substring(0, 2));
            int minute = Convert.ToInt32(sTime.Substring(3, 2));
            if (hour > 13 || hour < 9)
            {
                return "hour is between 9 to 13! please input again(hh:mm)!"; 
            }
            return "";
        }

        public string CheckInvalidStaffID(string staffID)
        {
            if (staffID[0] != 'e' || staffID.Length != 6)
            {
               return "the staffID must start 'e' and length is 6! please input again!";
            }
            var staff = _context.User.Select(t => t).Where(t => t.UserID == staffID).ToList();
            if (staff == null)
            {
                return "the database not has the staffID! please input again!"; 
            }
            return "";
        }
         
        [HttpPost, ActionName("CreateSlot")]
        [ValidateAntiForgeryToken]
        public IActionResult CreateSlot()
        {
            if(SetInfo() == "")
            {
                return Redirect("/Users/Login");
            }
            ViewData["Message"] = CheckInvalidDate(Request.Form["Date"]);
            string roomName = Request.Form["RoomName"];
            string time = Request.Form["Time"];
            string staffID = ViewBag.username;
            if (CheckInvalidRoomId(roomName) != "")
            {
                ViewData["Message"] = CheckInvalidRoomId(roomName);
                return View();
            }
            if (CheckInvalidDate(Request.Form["Date"]) != "")
            {
                return View();
            }
            if (CheckInvalidTime(time) != "")
            {
                ViewData["Message"] = CheckInvalidTime(time);
                return View();
            }
            if (CheckInvalidStaffID(staffID) != "")
            {
                ViewData["Message"] = CheckInvalidStaffID(staffID);
                return View();
            }
            string date = GetDateFormat(Request.Form["Date"]);
            List<Slot> listSlot = _context.Slot.Select(t => t).Where(t => t.RoomID == roomName).Where(t => t.StartTime.Contains(date + " "+ time)).ToList();
            if(listSlot.Count > 0)
            {
                ViewData["Message"] = "Unable to create slot. The Slot is exist!";
                return View();
            }
            listSlot = _context.Slot.Select(t => t).Where(t => t.StaffID == staffID).Where(t => t.StartTime.Contains(date)).ToList();
            if (listSlot.Count >= 4)
            {
                ViewData["Message"] = "Unable to create slot. one staff not have more than 4 slots at one day!";
                return View();
            }
            listSlot = _context.Slot.Select(t => t).Where(t => t.RoomID == roomName).Where(t => t.StartTime.Contains(date)).ToList();
            if (listSlot.Count >= 2)
            {
                ViewData["Message"] = "Unable to create slot. one room not have more than 2 slots at one day!";
                return View();
            }
            Slot slot = new Slot();
            slot.RoomID = roomName;
            slot.StaffID = staffID;
            slot.StartTime = date + " " + time;
            _context.Add(slot);
            _context.SaveChanges();
            return View();
        }

        public IActionResult DeleteSlot(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Slot slot = _context.Slot
                .Select(t => t).Where(t => t.Id == id).ToArray()[0];
            if (slot == null)
            {
                return NotFound();
            } 
            _context.Slot.Remove(slot);
            _context.SaveChangesAsync();
            return RedirectToAction(nameof(RemoveSlot));
        }

        public IActionResult RemoveSlot()
        {
            if (SetInfo() == "")
            {
                return Redirect("/Users/Login");
            }
            string staffid = Request.Cookies["userToken"].ToString().Split('-')[0];
            //return View(_context.Slot.Select(t => t).Where(t => t.StaffID == staffid).Where(t => t.BookedInStudentID == null));
            return View(_context.Slot.Select(t => t).Where(t => t.StaffID == staffid));
        }
         
        [HttpPost, ActionName("StaffAvaliable")]
        [ValidateAntiForgeryToken]
        public IActionResult StaffAvaliable()
        {
            if(SetInfo() == "")
            {
                return Redirect("/Users/Login");
            }
            ViewData["Message"] = CheckInvalidDate(Request.Form["Time"]);
            if (CheckInvalidDate(Request.Form["Time"]) != "")
            {
                return View();
            }
            string staffID = Request.Form["StaffID"];
            if (CheckInvalidStaffID(staffID) != "")
            {
                ViewData["Message"] = CheckInvalidStaffID(staffID);
                return View();
            }
            string time = GetDateFormat(Request.Form["Time"]);
            List<Slot> listSlot = _context.Slot.Select(t => t).Where(t => t.StaffID == staffID).Where(t => t.StartTime.Contains(time)).Where(t=>t.BookedInStudentID == null || t.BookedInStudentID.Length == 0).ToList();

            return View(listSlot);
        }

        [HttpPost, ActionName("MakeBooking")]
        [ValidateAntiForgeryToken]
        public IActionResult MakeBooking()
        {
            if(SetInfo() == "")
            {
                return Redirect("/Users/Login");
            }
            ViewData["Message"] = CheckInvalidDate(Request.Form["Date"]);
            string roomName = Request.Form["RoomName"];
            string time = Request.Form["Time"];
            string studentID = ViewBag.username;
            if (CheckInvalidRoomId(roomName) != "")
            {
                ViewData["Message"] = CheckInvalidRoomId(roomName);
                return View();
            }
            if (CheckInvalidDate(Request.Form["Date"]) != "")
            {
                return View();
            }
            if (CheckInvalidTime(time) != "")
            {
                ViewData["Message"] = CheckInvalidTime(time);
                return View();
            }
            if (CheckInvalidStudentID(studentID) != "")
            {
                ViewData["Message"] = CheckInvalidStudentID(studentID);
                return View();
            }
            string date = GetDateFormat(Request.Form["Date"]);
            List<Slot> listSlot = _context.Slot.Select(t => t).Where(t => t.BookedInStudentID == studentID).Where(t => t.StartTime.Contains(date)).ToList();
            if (listSlot.Count > 0)
            {
                ViewData["Message"] = "Unable to book slot.";
                return View();
            }
            listSlot = _context.Slot.Select(t => t).Where(t => t.StartTime.Contains(date + " " + time)).ToList();
            if (listSlot.Count == 0)
            {
                ViewData["Message"] = "Unable to create slot.";
                return View();
            }
            if (listSlot[0].BookedInStudentID != null && listSlot[0].BookedInStudentID.Length > 0)
            {
                ViewData["Message"] = "Unable to create slot. The slot had been Booked!";
                return View();
            }
            listSlot[0].BookedInStudentID = studentID;
            _context.Update(listSlot[0]);
            _context.SaveChanges();
            return View();
        }

        public string CheckInvalidStudentID(string studentID)
        {
            if (studentID[0] != 's' || studentID.Length != 8)
            {
                return "the staffID must start 's' and length is 8! please input again!"; 
            }
            var staff = _context.User.Select(t => t).Where(t => t.UserID == studentID).ToList();
            if (staff == null)
            {
                return  "the database not has the studentID! please input again!"; 
            }
            return "";
        }



        public IActionResult DeleteBooking(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Slot slot = _context.Slot
                .Select(t => t).Where(t => t.Id == id).ToArray()[0];
            if (slot == null)
            {
                return NotFound();
            }
            slot.BookedInStudentID = "";
            _context.Slot.Update(slot);
            _context.SaveChangesAsync();
            return RedirectToAction(nameof(CancelBooking));
        }


        public IActionResult CancelBooking()
        {
            if(SetInfo() == "")
            {
                return Redirect("/Users/Login");
            }
            string studentid = Request.Cookies["userToken"].ToString().Split('-')[0];
            return View(_context.Slot.Select(t => t).Where(t => t.BookedInStudentID == studentid));
        }

    }
}
