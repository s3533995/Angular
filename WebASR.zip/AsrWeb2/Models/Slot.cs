﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AsrWeb2.Models
{
    public class Slot
    {
        public int Id { get; set; }

        [Required]
        public string RoomID { get; set; }         
        public string BookedInStudentID { get; set; }
        [Required]
        public string StaffID { get; set; }
        public string StartTime { get; set; }
    }
}
