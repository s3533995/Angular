﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AsrWeb2.Models
{
    public class User
    {        
        public int Id { get; set; }

        [Required]
        [RegularExpression(@"^s\d{7}|e\d{5}$", ErrorMessage = "Please input staff or student id")]
        public string UserID { get; set; }

        [Required]
        [MinLength(3, ErrorMessage = "has more than 3 charaters")]
        public string Name { get; set; }

        [Required]
        [EmailAddress]
        [RegularExpression(@"^s\d{7}@student.rmit.edu.au|e\d{5}@rmit.edu.au$", ErrorMessage = "Email address is not in a valid format.")]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        [MinLength(6, ErrorMessage = "has more than 6 charaters")]
        public string PassWord { get; set; }
    }
}
