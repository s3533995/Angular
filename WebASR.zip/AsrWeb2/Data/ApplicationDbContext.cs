﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using AsrWeb2.Models;

namespace AsrWeb2.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<AsrWeb2.Models.FAQ> FAQ { get; set; }
        public DbSet<AsrWeb2.Models.Room> Room { get; set; }
        public DbSet<AsrWeb2.Models.Slot> Slot { get; set; }
        public DbSet<AsrWeb2.Models.User> User { get; set; }
    }
}
